Action()
{

	lr_start_transaction("1_OpenUrl");

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");

/*Correlation comment - Do not change!  Original value='CATS' Name ='C_Category' Type ='Manual'*/
	web_reg_save_param_regexp(
		"ParamName=C_Category",
		"RegExp=categories/(.*)\">",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	web_url("jpetstore.aspectran.com", 
		"URL=https://jpetstore.aspectran.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTTP", 
		LAST);
		

	web_concurrent_start(NULL);

	web_url("splash.gif", 
		"URL=https://jpetstore.aspectran.com/images/splash.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://jpetstore.aspectran.com/", 
		"Snapshot=t2.inf", 
		LAST);

	web_url("logo-topbar.gif", 
		"URL=https://jpetstore.aspectran.com/images/logo-topbar.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://jpetstore.aspectran.com/", 
		"Snapshot=t3.inf", 
		LAST);

	web_url("pets.png", 
		"URL=https://petclinic.aspectran.com/images/pets.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://jpetstore.aspectran.com/", 
		"Snapshot=t4.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_end_transaction("1_OpenUrl",LR_AUTO);

	lr_think_time(56);

	lr_start_transaction("2_Category");

/*Correlation comment - Do not change!  Original value='FL-DSH-01' Name ='C_Product' Type ='Manual'*/
	web_reg_save_param_regexp(
		"ParamName=C_Product",
		"RegExp=products/(.*?)\">",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	web_url("Cats",
		"URL=https://jpetstore.aspectran.com/categories/{C_Category}",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://jpetstore.aspectran.com/",
		"Snapshot=t5.inf",
		"Mode=HTTP",
		LAST);

	lr_end_transaction("2_Category",LR_AUTO);

	lr_think_time(17);

	lr_start_transaction("3_Product");

/*Correlation comment - Do not change!  Original value='EST-34' Name ='C_Item' Type ='Manual'*/
	web_reg_save_param_regexp(
		"ParamName=C_Item",
		"RegExp=items/(.*?)\">",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	web_url("FL-DSH-01",
		"URL=https://jpetstore.aspectran.com/products/{C_Product}",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://jpetstore.aspectran.com/categories/{C_Category}",
		"Snapshot=t6.inf",
		"Mode=HTTP",
		LAST);

	lr_end_transaction("3_Product",LR_AUTO);

	lr_think_time(17);

	lr_start_transaction("4_item");

	web_url("EST-34",
		"URL=https://jpetstore.aspectran.com/products/{C_Product}/items/{C_Item}",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://jpetstore.aspectran.com/products/{C_Product}",
		"Snapshot=t7.inf",
		"Mode=HTTP",
		LAST);

	web_url("cat2.gif",
		"URL=https://jpetstore.aspectran.com/images/cat2.gif",
		"Resource=1",
		"RecContentType=image/gif",
		"Referer=https://jpetstore.aspectran.com/products/{C_Product}/items/{C_Item}",
		"Snapshot=t8.inf",
		LAST);

	lr_end_transaction("4_item",LR_AUTO);

	lr_start_transaction("5_AddToCart");

	web_url("Add to Cart",
		"URL=https://jpetstore.aspectran.com/cart/addItemToCart?itemId={C_Item}",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://jpetstore.aspectran.com/products/{C_Product}/items/{C_Item}",
		"Snapshot=t9.inf",
		"Mode=HTTP",
		LAST);

	lr_end_transaction("5_AddToCart",LR_AUTO);

	lr_start_transaction("6_Checkout");

	web_url("Proceed to Checkout", 
		"URL=https://jpetstore.aspectran.com/order/newOrderForm", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/cart/viewCart", 
		"Snapshot=t10.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("6_Checkout",LR_AUTO);

	lr_start_transaction("7_Login");

	web_submit_data("signon", 
		"Action=https://jpetstore.aspectran.com/account/signon", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/account/signonForm?referer=/order/newOrderForm", 
		"Snapshot=t11.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=referer", "Value=/order/newOrderForm", ENDITEM, 
		"Name=username", "Value={P_Username}", ENDITEM, 
		"Name=password", "Value={P_Password}", ENDITEM, 
		LAST);

	web_url("banner_dogs.gif", 
		"URL=https://jpetstore.aspectran.com/images/banner_dogs.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://jpetstore.aspectran.com/order/newOrderForm", 
		"Snapshot=t12.inf", 
		LAST);

	lr_end_transaction("7_Login",LR_AUTO);

	lr_start_transaction("8_continue");

	web_submit_data("newOrder", 
		"Action=https://jpetstore.aspectran.com/order/newOrder", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/order/newOrderForm", 
		"Snapshot=t13.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=paymentForm", "Value=true", ENDITEM, 
		"Name=billingForm", "Value=true", ENDITEM, 
		"Name=cardType", "Value=Visa", ENDITEM, 
		"Name=creditCard", "Value={P_CreditCard}", ENDITEM, 
		"Name=expiryDate", "Value={P_DateTime}", ENDITEM, 
		"Name=billToFirstName", "Value=Test", ENDITEM, 
		"Name=billToLastName", "Value=User", ENDITEM, 
		"Name=billAddress1", "Value=123 Test St", ENDITEM, 
		"Name=billAddress2", "Value=123 Test St", ENDITEM, 
		"Name=billCity", "Value=Testville", ENDITEM, 
		"Name=billState", "Value=CA", ENDITEM, 
		"Name=billZip", "Value={P_RandomNumber}", ENDITEM, 
		"Name=billCountry", "Value=US", ENDITEM, 
		LAST);

	lr_end_transaction("8_continue",LR_AUTO);

	lr_start_transaction("9_confirm");

	web_submit_data("submitOrder", 
		"Action=https://jpetstore.aspectran.com/order/submitOrder", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/order/newOrder", 
		"Snapshot=t14.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=confirmed", "Value=true", ENDITEM, 
		LAST);

	lr_end_transaction("9_confirm",LR_AUTO);

	return 0;
}